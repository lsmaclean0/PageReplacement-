/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pagereplace;
import java.util.*; 

/**
 *
 * @author dswilliams0
 */
public abstract class LRU extends ReplacementAlgorithm{
    public static void main(String[] args) { 
        int capacity = 4; 
        int arr[] = {};
      
        
          
        // To represent set of current pages.We use 
        // an Arraylist 
        ArrayList<Integer> s=new ArrayList<>(capacity); 
        int count=0; 
        int page_faults=0; 
        for(int i:arr) 
        { 
            // Insert it into set if not present 
            // already which represents page fault 
            if(!s.contains(i)) 
            { 
              
            // Check if the set can hold equal pages 
            if(s.size()==capacity) 
            { 
                s.remove(0); 
                s.add(capacity-1,i); 
            } 
            else
                s.add(count,i); 
                // Increment page faults 
                page_faults++; 
                ++count; 
          
            } 
            else
            { 
                // Remove the indexes page 
                s.remove((Object)i); 
                // insert the current page 
                s.add(s.size(),i);          
            } 
          
        } 
        System.out.println("LRU Page Faults: " + page_faults); 
    }  

    public LRU(int pageFrameCount) {
        super(pageFrameCount);
    }

} 


