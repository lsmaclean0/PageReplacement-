/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package pagereplace;

import java.io.*;
import java.util.*;
import pagereplace.FIFO;

public class PageReplace {

  
    public static void main(String[] args) throws FileNotFoundException {
        Scanner a = new Scanner(System.in);
        System.out.println("Enter file name: ");
        String b = a.next();
        File file = new File(b);
        Scanner n = new Scanner (file);
        System.out.println("Enter the amount of frames: ");
        int frame = a.nextInt();
        ArrayList<String> string = new ArrayList<>();
        
        //Reference String (current)
        String referenceString;
        
        //loop over file
        while(n.hasNextLine()){
            referenceString = n.nextLine();
            String s = referenceString.replaceAll(" ", " ");
            string.add(s);
        }
        
        
        FIFO f = new FIFO();
        System.out.println("FIFO page faults " + frame + " frames: ");
        
        //loops the reference strings
        for(int x=0; x < string.size(); x++){
            f.pageFaultCount = 0;
            String test = string.get(x);
            String[] t = test.split("");
            int c[] = new int[test.length()];
            for(int y=0; y < t.length; y++){
                c[y]= Integer.parseInt(t[y]);
            }
            
            System.out.println(f.FIFO (c, c.length, frame));
            
            System.out.println(r.LRU (c, c.length, frame));
            
            }
        }
        
    }


